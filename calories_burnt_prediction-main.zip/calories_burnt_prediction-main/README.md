<h1>Guide to run this notebook</h1>

<h3>Fork this repository</h3>
<h3>then clone using this command in command prompt or in any terminal (before this make sure git is installed in your laptop) -</h3>
`git clone https://github.com/shourya-khatiyan/calories_burnt_prediction.git` - <h3>now this repo will be cloned in your system. Just follow the following for further setup </h3>

---

<h3>simply download jupyter</h3>
<h3>keep both dataset and the notebook in one directory</h3>
<h3>to install required libraries >copy and paste this command in command prompt or any in terminal -  </h3>
pip install pandas numpy scikit-learn matplotlib
<h3>finally run all the cells by pressing shift enter in each cell (run one shell at a time, wait for it to run completely then run next shell)</h3>
